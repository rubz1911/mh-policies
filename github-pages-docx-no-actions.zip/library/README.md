Upload your .docx files into this folder via GitHub’s web UI.
